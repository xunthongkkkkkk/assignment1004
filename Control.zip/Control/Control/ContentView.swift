//
//  ContentView.swift
//  Control
//
//  Created by Ayan on 23/11/21.
//

import SwiftUI
struct ContentView: View {
    @State var IP: String = ""
    var body: some View {
            NavigationView {
                VStack {
                    TextField("Enter your Raspberry Pi's IP Address", text: $IP)
                        .padding(.init(top: 0, leading: 15, bottom:0 , trailing: 15))
                        .foregroundColor(.black)
                        .textFieldStyle(RoundedBorderTextFieldStyle.init())
                        
                    NavigationLink(destination: secondPage(IP: self.$IP)) {
                        Text("Enter")
                            .font(.subheadline)
                            .foregroundColor(.white)
                            .padding(10)
                            .background(Color.blue)
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                }
            }
        }
    }
}
struct secondPage: View {
    var url1 : String = "https://www.google"
    //Red Light On: <IP>/index.php?redL=ron
    //Red Light Off: <IP>/index.php?redL=roff
    //Red Light Blink: <IP>/index.php?redL=rblink
    //Green Light On: <IP>/index.php?redL=gon
    //Green Light Off: <IP>/index.php?redL=goff
    //Green Light Blink: <IP>/index.php?redL=gblink
    @Binding var IP: String
    var body: some View{
        let urlRon : String = "http://\(IP)/index.php?redL=ron"
        let urlRoff : String = "http://\(IP)/index.php?redL=roff"
        let urlRBlinkStart : String = "http://\(IP)/index.php?redL=rblink"
        let urlGon : String = "http://\(IP)/index.php?greenL=gon"
        let urlGoff : String = "http://\(IP)/index.php?greenL=goff"
        let urlGBlinkStart : String = "http://\(IP)/index.php?greenL=gblink"
        VStack (spacing:80){
            VStack (spacing:10){
                SwiftUI.Text("Red Light")
                    .font(.largeTitle)
                    .frame(width:300)
                HStack (spacing:60) {
                    
                    Link("On",
                         destination:URL(string: urlRon)!)
                        .foregroundColor(.white)
                            .padding()
                            .background(Color.green)
                            .cornerRadius(8)
                    
                    Link("Off",
                         destination: URL(string: urlRoff)!)
                        .foregroundColor(.white)
                            .padding()
                            .background(Color.red)
                            .cornerRadius(8)
                    
                }
                HStack (spacing:20) {
                    
                    
                    Link("Start Blink", destination: URL(string: urlRBlinkStart)!)
                        .foregroundColor(.white)
                            .padding()
                            .background(Color.green)
                            .cornerRadius(8)
                    
                    Link("Stop Blink", destination: URL(string: urlRBlinkStart)!)
                        .foregroundColor(.white)
                            .padding()
                            .background(Color.red)
                            .cornerRadius(8)
                }
            }
    
        
            VStack (spacing:10){
                SwiftUI.Text("Green Light")
                    .font(.largeTitle)
                    .frame(width:300)
                HStack (spacing:60) {
                    
                    Link("On",
                    destination:URL(string: urlGon)!)
                        .foregroundColor(.white)
                            .padding()
                            .background(Color.green)
                            .cornerRadius(8)
                    
                    
                    Link("Off",
                         destination: URL(string: urlGoff)!)
                        .foregroundColor(.white)
                            .padding()
                            .background(Color.red)
                            .cornerRadius(8)
                    
                }
                HStack (spacing:20) {
                    
                    
                    Link("Start Blink", destination: URL(string: urlGBlinkStart)!)
                        .foregroundColor(.white)
                            .padding()
                            .background(Color.green)
                            .cornerRadius(8)
                    
                    
                    Link("Stop Blink", destination: URL(string: urlGBlinkStart)!)
                        .foregroundColor(.white)
                            .padding()
                            .background(Color.red)
                            .cornerRadius(8)
                }
            }
    }
    }
}
        



struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
.previewInterfaceOrientation(.portrait)
    }
}



