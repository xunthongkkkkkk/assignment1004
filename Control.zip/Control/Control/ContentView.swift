//
//  ContentView.swift
//  Control
//
//  Created by Ayan on 23/11/21.
//

import SwiftUI
struct ContentView: View {
    //Declaring string type variable to use to capture user's IP address
    @State var IP: String = ""
    var body: some View {
            NavigationView {
                VStack {
                    TextField("Enter your Raspberry Pi's IP Address", text: $IP)        //Captures IP address and stores into string variable, IP to be called upon
                    //Giving textfield style
                        .padding(.init(top: 0, leading: 15, bottom:0 , trailing: 15))
                        .foregroundColor(.black)
                        .textFieldStyle(RoundedBorderTextFieldStyle.init())
                        
                    NavigationLink(destination: secondPage(IP: self.$IP)) {
                        Text("Enter")
                        //Giving page style
                            .font(.subheadline)
                            .foregroundColor(.white)
                            .padding(10)
                            .background(Color.blue)
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                }
            }
        }
    }
}
struct secondPage: View {
    var url1 : String = "https://www.google"
    @Binding var IP: String
    var body: some View{
        //Declaring each action to a specific url link
        let urlRon : String = "http://\(IP)/index.php?redL=ron"
        let urlRoff : String = "http://\(IP)/index.php?redL=roff"
        let urlRBlinkStart : String = "http://\(IP)/index.php?redL=rblink"
        let urlGon : String = "http://\(IP)/index.php?greenL=gon"
        let urlGoff : String = "http://\(IP)/index.php?greenL=goff"
        let urlGBlinkStart : String = "http://\(IP)/index.php?greenL=gblink"
        //Creating the View for second page with Link buttons and Titles
        VStack (spacing:80){
            VStack (spacing:10){
                //Code for everything under Red Light
                SwiftUI.Text("Red Light")
                    .font(.largeTitle)
                    .frame(width:300)
                HStack (spacing:60) {
                    
                    Link("On",
                         destination:URL(string: urlRon)!)
                        .foregroundColor(.white)
                            .padding()
                            .background(Color.green)
                            .cornerRadius(8)
                    
                    Link("Off",
                         destination: URL(string: urlRoff)!)
                        .foregroundColor(.white)
                            .padding()
                            .background(Color.red)
                            .cornerRadius(8)
                    
                }
                HStack (spacing:20) {
                    
                    
                    Link("Start Blink", destination: URL(string: urlRBlinkStart)!)
                        .foregroundColor(.white)
                            .padding()
                            .background(Color.green)
                            .cornerRadius(8)
                    
                    Link("Stop Blink", destination: URL(string: urlRBlinkStart)!)
                        .foregroundColor(.white)
                            .padding()
                            .background(Color.red)
                            .cornerRadius(8)
                }
            }
    
        
            VStack (spacing:10){
                //Code for everything under Green Light
                SwiftUI.Text("Green Light")
                    .font(.largeTitle)
                    .frame(width:300)
                HStack (spacing:60) {
                    
                    Link("On",
                    destination:URL(string: urlGon)!)
                        .foregroundColor(.white)
                            .padding()
                            .background(Color.green)
                            .cornerRadius(8)
                    
                    
                    Link("Off",
                         destination: URL(string: urlGoff)!)
                        .foregroundColor(.white)
                            .padding()
                            .background(Color.red)
                            .cornerRadius(8)
                    
                }
                HStack (spacing:20) {
                    
                    
                    Link("Start Blink", destination: URL(string: urlGBlinkStart)!)
                        .foregroundColor(.white)
                            .padding()
                            .background(Color.green)
                            .cornerRadius(8)
                    
                    
                    Link("Stop Blink", destination: URL(string: urlGBlinkStart)!)
                        .foregroundColor(.white)
                            .padding()
                            .background(Color.red)
                            .cornerRadius(8)
                }
            }
    }
    }
}
        



struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
.previewInterfaceOrientation(.portrait)
    }
}



