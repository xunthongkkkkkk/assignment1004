//
//  ControlApp.swift
//  Control
//
//  Created by Ayan on 23/11/21.
//

import SwiftUI

@main
struct ControlApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
